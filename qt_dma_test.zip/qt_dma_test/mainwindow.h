#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QTime>
#include <QTimer>
#include <QVector>
#include <QDebug>
#include <QThread>
#include <QTcpServer>
#include <QTcpSocket>
#include <QTimer>
#include <QModbusDevice>
#include <QSerialPort>
#include <QModbusRtuSerialSlave>
#include <QModbusTcpServer>
#include "dataprocess.h"
#include "uartlite.h"
#include "uart0_ps.h"
#include "utils.h"
extern "C"
{
    #include "gpio_ctrl.h"
    #include "libaxidma.h"
}

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

    int gpioInit();
    void threadInit();

signals:
    void openUartliteComSignal(int valuefd);
    void openUart0_PSComSignal();
    void openAxidmaDevSignal();

private:
    Ui::MainWindow *ui;

    dataprocess *dataprocessThread;
    QThread *dataprocessDoThread;
    uartlite *uartliteThread;
    QThread *uartliteDoThread;
    uart0_ps *uart0_psThread;
    QThread *uart0_psDoThread;
};

#endif // MAINWINDOW_H
