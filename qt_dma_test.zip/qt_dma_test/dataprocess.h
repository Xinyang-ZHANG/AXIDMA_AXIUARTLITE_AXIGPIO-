#ifndef DATAPROCESS_H
#define DATAPROCESS_H

#include <QObject>
extern "C"
{
    #include "libaxidma.h"
}

class dataprocess : public QObject
{
    Q_OBJECT
public:
    explicit dataprocess(QObject *parent = 0);

    int axidmaInit();

signals:
    void sendOutDataSignal(QByteArray ba);

public slots:
    void axidmaDataReceive(int len);

private:
    axidma_dev_t axidma_dev;
    const array_t *rx_chans;
    void *axidma_buf;
    qint32 axidma_data[256/sizeof(uint32_t)];
};

#endif // DATAPROCESS_H
