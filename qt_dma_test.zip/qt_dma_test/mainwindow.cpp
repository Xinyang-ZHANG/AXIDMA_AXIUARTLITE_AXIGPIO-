#include "mainwindow.h"
#include "uartlite.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    int valuefd = gpioInit();
    threadInit();

    emit openAxidmaDevSignal();
    emit openUartliteComSignal(valuefd);
    emit openUart0_PSComSignal();
}

MainWindow::~MainWindow()
{
    delete ui;
}

int MainWindow::gpioInit()
{
    //GPIO direction control init
    GPIO_export("/sys/class/gpio/export", "1023");
    GPIO_dirset("/sys/class/gpio/gpio1023/direction", "out");
    int valuefd = GPIO_toggle("/sys/class/gpio/gpio1023/value");
    if(valuefd < 0){
        qDebug() << "Cannot open GPIO value";
    }
    qDebug() << "GPIO value opened, now toggling...";

    //GPIO value init
    GPIO_write_low(valuefd);

    return valuefd;
}

void MainWindow::threadInit()
{
    dataprocessThread =new dataprocess();
    dataprocessDoThread =new QThread();
    dataprocessThread->moveToThread(dataprocessDoThread);
    dataprocessDoThread->start();

    uart0_psThread =new uart0_ps();
    uart0_psDoThread =new QThread();
    uart0_psThread->moveToThread(uart0_psDoThread);
    uart0_psDoThread->start();

    uartliteThread =new uartlite();
    uartliteDoThread =new QThread();
    uartliteThread->moveToThread(uartliteDoThread);
    uartliteDoThread->start();

    connect(this, &MainWindow::openAxidmaDevSignal, dataprocessThread, &dataprocess::axidmaInit);
    connect(this, &MainWindow::openUart0_PSComSignal, uart0_psThread, &uart0_ps::openComSlot);
    connect(this, &MainWindow::openUartliteComSignal, uartliteThread, &uartlite::openComSlot);

    connect(uartliteThread, &uartlite::sendSignal, uart0_psThread, &uart0_ps::sendSlot);
    connect(uart0_psThread, &uart0_ps::axidmaReceiveStartSignal, dataprocessThread, &dataprocess::axidmaDataReceive);
    connect(dataprocessThread, &dataprocess::sendOutDataSignal, uartliteThread, &uartlite::sendSlot);
}
