#include "uart0_ps.h"
#include <QVector>
#include <QDebug>
#include <QThread>

uart0_ps::uart0_ps(QObject *parent) : QObject(parent)
{
    uart0_psCom = new QSerialPort();

    //设置串口名
    uart0_psComSettings.name = "/dev/ttyPS1";
    uart0_psComSettings.baudRate    = 115200;
    uart0_psComSettings.dataBits    = QSerialPort::Data8;
    uart0_psComSettings.parity      = QSerialPort::NoParity;
    uart0_psComSettings.stopBits    = QSerialPort::OneStop;
    uart0_psComSettings.flowControl = QSerialPort::NoFlowControl;
}

void uart0_ps::openComSlot()
{
    uart0_psCom->setPortName(uart0_psComSettings.name);
    uart0_psCom->setBaudRate(uart0_psComSettings.baudRate);
    uart0_psCom->setDataBits(uart0_psComSettings.dataBits);
    uart0_psCom->setParity(uart0_psComSettings.parity);
    uart0_psCom->setStopBits(uart0_psComSettings.stopBits);
    uart0_psCom->setFlowControl(uart0_psComSettings.flowControl);

    if (uart0_psCom->open(QIODevice::ReadWrite)) {
        qDebug()<<"uart0_psCom openSerialPort success";
    } else {
        qDebug()<<"uart0_psCom openSerialPort failed";
    }
}

void uart0_ps::sendSlot(QByteArray ba, int len)
{
    if (uart0_psCom->isOpen())
    {
        qDebug() << "Send uart0_psCom data!" << ba.toHex();

        uart0_psCom->write(ba);
        emit axidmaReceiveStartSignal(len);
    }
}
