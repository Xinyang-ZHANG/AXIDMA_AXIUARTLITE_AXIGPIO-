#include "dataprocess.h"
#include <QVector>
#include <QDebug>
#include <QThread>

dataprocess::dataprocess(QObject *parent) : QObject(parent)
{

}

int dataprocess::axidmaInit()
{
    //AXIDMA init
    axidma_dev = axidma_init();//初始化DMA设备
    if (axidma_dev == NULL) {
        qDebug() << "Error: Failed to initialize the AXI DMA device.";
        return -1;
    }

    rx_chans = axidma_get_dma_rx(axidma_dev);//从DMA设备获取接收通道
    if (rx_chans->len < 1) {
        qDebug() << "Error: No receive channels were found.";
        axidma_destroy(axidma_dev);
        return -1;
    }
    //print avaliable rx channels
    int i;
    for(i=0;i<rx_chans->len;i++)
    {
        qDebug() << "INFO: receive channel ID: " << rx_chans->data[i];
    }
    axidma_buf = axidma_malloc(axidma_dev,256);//从DMA设备分配256字节专用DMA内存
    if (axidma_buf== NULL) {
        qDebug() << "The DMA buffer malloc_error!";
        axidma_destroy(axidma_dev);
        return -1;
    }

    return 0;
}

void dataprocess::axidmaDataReceive(int len)
{
    QByteArray receivedBa;

    //AXIDMA
    axidma_buf = axidma_malloc(axidma_dev,256);//从DMA设备分配256字节专用DMA内存
    if(axidma_buf== NULL) {
        printf("The DMA buffer malloc_error!\n");
        axidma_destroy(axidma_dev);
    }
    //AXIDMA transfer
    int ret = axidma_oneway_transfer(axidma_dev,rx_chans->data[0],axidma_buf,4*(len+4),1);//最后一个参数为true表示该函数阻塞，若为false则为非阻塞，用户需要自己注册一个回调函数
    //stop axidma
    axidma_stop_transfer(axidma_dev,rx_chans->data[0]);
    memcpy(axidma_data,axidma_buf,4*(len+4));
    axidma_free(axidma_dev,axidma_buf,256);//释放DMA内存

    if(ret<0)
    {
        qDebug() << "received error!";
    }
    else
    {
        qDebug() << "AXIDMA RECEIVE DATA : ";
        for(int i=1; i<(len+2); i++){
            if(i == len+1)
                printf("%x\n", axidma_data[i]);
            else
                printf("%x ", axidma_data[i]);

            QByteArray temp(sizeof(qint32), '\0');
            memcpy(temp.data(), &axidma_data[i], sizeof(qint32)); //Copy the data into the QByteArray

            receivedBa.append(temp);
        }
    }

    emit sendOutDataSignal(receivedBa);
}
