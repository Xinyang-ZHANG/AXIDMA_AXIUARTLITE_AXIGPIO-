#ifndef UART0_PS_H
#define UART0_PS_H

#include <QObject>
#include <QtSerialPort/QSerialPort>
#include <QtSerialPort/QSerialPortInfo>
#include <QTimer>
#include "utils.h"

class uart0_ps : public QObject
{
    Q_OBJECT
public:
    explicit uart0_ps(QObject *parent = nullptr);

public slots:
    void openComSlot();
    void sendSlot(QByteArray ba, int len);

signals:
    void axidmaReceiveStartSignal(int len);

private:
    QSerialPort *uart0_psCom;
    comSettings uart0_psComSettings;
};

#endif // UART0_PS_H
