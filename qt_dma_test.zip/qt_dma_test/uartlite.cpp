#include "uartlite.h"
#include <QVector>
#include <QDebug>
#include <QThread>

uartlite::uartlite(QObject *parent) : QObject(parent)
{
    uartliteCom = new QSerialPort();

    timer = new QTimer(this);
    timer->start(250);
    connect(timer,SIGNAL(timeout()),this,SLOT(receiveSlot()));//客户端读取内容信号连接槽

    //设置串口名
    uartliteComSettings.name = "/dev/ttyUL1";
    uartliteComSettings.baudRate    = 115200;
    uartliteComSettings.dataBits    = QSerialPort::Data8;
    uartliteComSettings.parity      = QSerialPort::NoParity;
    uartliteComSettings.stopBits    = QSerialPort::OneStop;
    uartliteComSettings.flowControl = QSerialPort::NoFlowControl;
}

void uartlite::openComSlot(int valuefd)
{
    uartliteCom->setPortName(uartliteComSettings.name);
    uartliteCom->setBaudRate(uartliteComSettings.baudRate);
    uartliteCom->setDataBits(uartliteComSettings.dataBits);
    uartliteCom->setParity(uartliteComSettings.parity);
    uartliteCom->setStopBits(uartliteComSettings.stopBits);
    uartliteCom->setFlowControl(uartliteComSettings.flowControl);
    gpiovaluefd = valuefd;
    //connect(uartliteCom,SIGNAL(readyRead()),this,SLOT(receiveSlot()));//客户端读取内容信号连接槽

    if (uartliteCom->open(QIODevice::ReadWrite)) {
        qDebug()<<"uartliteCom openSerialPort success";
    } else {
        qDebug()<<"uartliteCom openSerialPort failed";
    }
}

void uartlite::receiveSlot()
{
    GPIO_write_low(gpiovaluefd);

    if(uartliteCom->bytesAvailable() <= 0) {
        return;
    }

    QByteArray buffer;

    buffer = uartliteCom->readAll();

    receiveBuffer.append(buffer);            //贴包处理
    receiveBuffer.toHex();                   //将数据转为16进制
    int totalLen = receiveBuffer.size();     //缓存区的总长度

    //不够包头的数据直接就不处理
    if(totalLen < 2) {
        return;
    }


    //receiving data
    int datalen=0;
    QByteArray receivedBa;

    int headIndex = receiveBuffer.indexOf((char)0x55,0);

    if(headIndex != -1){
        datalen = receiveBuffer[1];
        if(totalLen == datalen+2){
            receivedBa = receiveBuffer.mid(headIndex,datalen+2);
            emit sendSignal(receivedBa, datalen);

            //clear
            receiveBuffer.clear();
        }
        else{
            qDebug() << "Length number wrong!" << datalen << totalLen;
            return;
        }
    }
    else {
        qDebug() << "Header wrong!" << headIndex;
    }
}

void uartlite::sendSlot(QByteArray ba)
{
    if (uartliteCom->isOpen())
    {
        qDebug() << "Send uartliteCom data!" << ba.toHex();

        GPIO_write_high(gpiovaluefd);
        uartliteCom->write(ba);
    }
}
