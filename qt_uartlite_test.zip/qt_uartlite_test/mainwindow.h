#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QTime>
#include <QTimer>
#include <QVector>
#include <QDebug>
#include <QThread>
#include <QTcpServer>
#include <QTcpSocket>
#include <QTimer>
#include <QModbusDevice>
#include <QSerialPort>
#include <QModbusRtuSerialSlave>
#include <QModbusTcpServer>
#include "uartlite.h"
extern "C"
{
    #include "gpio_ctrl.h"
}

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

    int gpioInit();
    void threadInit();

signals:
    void openUartliteComSignal(int valuefd);

private:
    Ui::MainWindow *ui;

    uartlite *uartliteThread;
    QThread *uartliteDoThread;
};

#endif // MAINWINDOW_H
