#ifndef UARTLITE_H
#define UARTLITE_H

#include <QObject>
#include <QtSerialPort/QSerialPort>
#include <QtSerialPort/QSerialPortInfo>
#include <QTimer>
extern "C"
{
    #include "gpio_ctrl.h"
}

struct comSettings {
    QString name;
    qint32 baudRate;
    QSerialPort::DataBits dataBits;
    QSerialPort::Parity parity;
    QSerialPort::StopBits stopBits;
    QSerialPort::FlowControl flowControl;
    bool localEchoEnabled;
};

class uartlite : public QObject
{
    Q_OBJECT
public:
    explicit uartlite(QObject *parent = nullptr);

public slots:
    void openComSlot(int valuefd);
    void receiveSlot();
    void sendSlot(QByteArray ba);

signals:
    void sendSignal(QByteArray ba);

private:
    QSerialPort *uartliteCom;
    comSettings uartliteComSettings;

    QByteArray receiveBuffer;

    QTimer *timer;
    int gpiovaluefd;
};

#endif // UARTLITE_H
